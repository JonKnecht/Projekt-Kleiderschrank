/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

import model.Geschlecht;

/**
 *
 * @author Benni
 */
public enum Hose {
    JEANS(Geschlecht.DIVERS, "Kleidung\\Hosen\\Jeans.png"),
    SHORTJEANS(Geschlecht.WEIBLICH, "Kleidung\\Hosen\\ShortJeans.png"),
    LEGGINGS(Geschlecht.WEIBLICH, "Kleidung\\Hosen\\Leggings.png"),
    JOGGINGHOSE(Geschlecht.DIVERS, "Kleidung\\Hosen\\Jogginghose.png"),
    SHORTS(Geschlecht.MAENNLICH, "Kleidung\\Hosen\\Shorts.png"),
    ROCK(Geschlecht.WEIBLICH, "Kleidung\\Hosen\\Rock.png"),
    LEDERHOSE(Geschlecht.MAENNLICH, "Kleidung\\Hosen\\Lederhose.png");
    
    private Geschlecht i;
    private String path;
    
    private Hose(Geschlecht i, String path) {
        this.i = i;
        this.path = path;
    }

    public Geschlecht getI() {
        return i;
    }

    public String getPath() {
        return path;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafik;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.jersey.api.client.WebResource;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Date;
import java.util.LinkedList;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Geschlecht;
import model.Person;
import model.Wetter;
import model.kleidung.Hose;
import model.kleidung.Kopfbedeckung;
import model.kleidung.Oberkoerper;
import sun.net.www.protocol.https.HttpsURLConnectionImpl;

/**
 * FXML Controller class
 *
 * @author jerem
 */
public class OutfitFXMLController implements Initializable {

    @FXML
    private ImageView kopfImage;
    @FXML
    private ImageView obenImage;
    @FXML
    private ImageView untenImage;
    @FXML
    private Button changeButton;
    @FXML
    private AnchorPane anchor;
    @FXML
    private TextField ortField;
    @FXML
    private Button editButton;
    private Person person;
    @FXML
    private Label keinKopfLabel;
    @FXML
    private Label keinObenLabel;
    @FXML
    private Label keineHoseLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    private static final String seasons[] = {
        "Winter", "Winter", "Spring", "Spring", "Summer", "Summer",
        "Summer", "Summer", "Fall", "Fall", "Winter", "Winter"
    };

    public String getSeason(Date date) {
        return seasons[date.getMonth()];
    }

    @FXML
    private void handleChangeButton(ActionEvent event) throws IOException {

        keinKopfLabel.setText("");
        keinObenLabel.setText("");
        keineHoseLabel.setText("");
        JsonObject jo = getJsonWetterdaten(ortField.getText());
        System.out.println(jo.toString());
        String main = jo.getAsJsonArray("weather").get(0).getAsJsonObject().get("main").getAsString();
        int temp = jo.getAsJsonObject("main").getAsJsonObject().get("feels_like").getAsInt();

        Wetter w = null;
        for (int i = 0; i < person.getSchrank().getHose().size(); i++) {
            Hose s = person.getSchrank().getHose().get(i);
            s.setIstInSchrank(true);
        }
        for (int i = 0; i < person.getSchrank().getKopf().size(); i++) {
            Kopfbedeckung s = person.getSchrank().getKopf().get(i);
            s.setIstInSchrank(true);
        }
        for (int i = 0; i < person.getSchrank().getOberkoerper().size(); i++) {
            Oberkoerper s = person.getSchrank().getOberkoerper().get(i);
            s.setIsInSchrank(true);
        }
        Wetter wetter[] = Wetter.values();
        for (int i = 0; i < wetter.length; i++) {
            if (wetter[i].toString().equals(main)) {
                w = wetter[i];
            }

        }
        double temperatur = temp - 273.15;
        LinkedList<Hose> hose = hoseAlgorithus(w, temperatur);
        LinkedList<Oberkoerper> oben = ObenAlgorithus(w, temperatur);
        LinkedList<Kopfbedeckung> kopf = kopfAlgorithus(w, temperatur);
        Random ran = new Random();
        if (hose.size() == 0) {
            keineHoseLabel.setText("Keine passende Hose");
            untenImage.setVisible(false);
        } else {
            untenImage.setVisible(true);
            int randomHose = ran.nextInt(hose.size());
            untenImage.setImage(new Image(new FileInputStream(hose.get(randomHose).getPath())));
        }
        if (oben.size() == 0) {
            keinObenLabel.setText("Kein passendes Oberteil");
            obenImage.setVisible(false);
        } else {
            obenImage.setVisible(true);
            int randomOben = ran.nextInt(oben.size());
            obenImage.setImage(new Image(new FileInputStream(oben.get(randomOben).getPath())));
        }

        if (kopf.size() == 0) {
            keinKopfLabel.setText("Kein passender Hut");
            kopfImage.setVisible(false);
        } else {
            kopfImage.setVisible(true);
            int randomKopf = ran.nextInt(kopf.size());

            kopfImage.setImage(new Image(new FileInputStream(kopf.get(randomKopf).getPath())));
        }
    }

    private LinkedList<Hose> hoseAlgorithus(Wetter w, double temp) {
        Date d = new Date();
        LinkedList<Hose> ll = new LinkedList<>();
        for (Hose h : Hose.values()) {
            for (int i = 0; i < h.getMain().length; i++) {
                if (temp >= 20) {
                    if (h.getMain()[i] == w && h.isIstInSchrank() == true && h.isIstUeber20() == true && h.isIstWinter() == false) {
                        ll.add(h);
                    }
                } else if (temp < 20 && getSeason(d).equals("Winter")) {
                    if (h.getMain()[i] == w && h.isIstInSchrank() == true && h.isIstUeber20() == false && h.isIstWinter() == true) {
                        ll.add(h);
                    }
                } else {
                    if (h.getMain()[i] == w && h.isIstInSchrank() == true && h.isIstUeber20() == false && h.isIstWinter() == false) {
                        ll.add(h);
                    }
                }
            }
        }
        return ll;
    }

    private LinkedList<Oberkoerper> ObenAlgorithus(Wetter w, double temp) {
        LinkedList<Oberkoerper> ll = new LinkedList<>();
        for (Oberkoerper h : Oberkoerper.values()) {
            for (int i = 0; i < h.getMain().length; i++) {
                if (temp >= 20) {
                    if (h.getMain()[i] == w && h.isIsInSchrank() == true && h.isIstueber20() == true) {
                        ll.add(h);
                    }
                } else {
                    if (h.getMain()[i] == w && h.isIsInSchrank() == true && h.isIstueber20() == false) {
                        ll.add(h);
                    }

                }
            }
        }
        return ll;
    }

    private LinkedList<Kopfbedeckung> kopfAlgorithus(Wetter w, double temp) {
        LinkedList<Kopfbedeckung> ll = new LinkedList<>();
        for (Kopfbedeckung h : Kopfbedeckung.values()) {
            for (int i = 0; i < h.getMain().length; i++) {
                if (temp >= 20) {
                    if (h.getMain()[i] == w && h.isIstInSchrank() == true && h.isTemperature() == true) {
                        ll.add(h);
                    }
                } else {
                    if (h.getMain()[i] == w && h.isIstInSchrank() == true && h.isTemperature() == false) {
                        ll.add(h);
                    }
                }
            }
        }

        return ll;
    }

    @FXML
    private void handleEditButton(ActionEvent event) throws FileNotFoundException {
        OutfitWindow stage = (OutfitWindow) anchor.getScene().getWindow();
        stage.hide();
        KleiderschrankWindow kw = stage.getKldwdw();
        kw.show();
        kw.kfc.setSsKopfLauf(0);
        kw.kfc.getKldKopf().setImage(new Image(new FileInputStream(person.getSchrank().getKopf().get(kw.kfc.getSsKopfLauf()).getPath())));

        kw.kfc.setSsObenLauf(0);
        kw.kfc.getKldOben().setImage(new Image(new FileInputStream(person.getSchrank().getOberkoerper().get(kw.kfc.getSsObenLauf()).getPath())));

        kw.kfc.setSsHoseLauf(0);
        kw.kfc.getKldUnten().setImage(new Image(new FileInputStream(person.getSchrank().getHose().get(kw.kfc.getSsHoseLauf()).getPath())));

    }

    private static JsonObject getJsonWetterdaten(String ort) throws MalformedURLException, IOException {
        final String APIkey = "f60681cfe21d54e6f9268ea380d1e3a8";
        String urlString = "https://api.openweathermap.org/data/2.5/weather?q=" + ort + "&appid=" + APIkey;
        URL url = new URL(urlString);
        HttpsURLConnectionImpl conn = (HttpsURLConnectionImpl) url.openConnection();
        conn.connect();
        JsonParser jp = new JsonParser();
        JsonElement root = jp.parse(new InputStreamReader((InputStream) conn.getContent()));
        JsonObject obj = root.getAsJsonObject();
        return obj;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public Label getKeinKopfLabel() {
        return keinKopfLabel;
    }

    public void setKeinKopfLabel(Label keinKopfLabel) {
        this.keinKopfLabel = keinKopfLabel;
    }

    public Label getKeinObenLabel() {
        return keinObenLabel;
    }

    public void setKeinObenLabel(Label keinObenLabel) {
        this.keinObenLabel = keinObenLabel;
    }

    public Label getKeineHoseLabel() {
        return keineHoseLabel;
    }

    public void setKeineHoseLabel(Label keineHoseLabel) {
        this.keineHoseLabel = keineHoseLabel;
    }

}

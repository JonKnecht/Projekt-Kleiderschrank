/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

import java.util.LinkedList;
import model.Geschlecht;
import model.Wetter;

/**
 *
 * @author Benni
 */
public enum Hose {
    JEANS(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Hosen\\Jeans.png", new Wetter[]{Wetter.CLOUDS, Wetter.RAIN, Wetter.SNOW, Wetter.DRIZZLE, Wetter.THUNDERSTORM},false, false, true),
    SHORTJEANS(Geschlecht.WEIBLICH, "src\\grafik\\Kleidung\\Hosen\\ShortJeans.png", new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},true, false,false),
    LEGGINGS(Geschlecht.WEIBLICH, "src\\grafik\\Kleidung\\Hosen\\Leggings.png", new Wetter[]{Wetter.DRIZZLE, Wetter.RAIN},false, false,false),
    JOGGINGHOSE(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Hosen\\Jogginghose.png", new Wetter[]{Wetter.DRIZZLE, Wetter.RAIN}, true, false,false),
    SHORTS(Geschlecht.MAENNLICH, "src\\grafik\\Kleidung\\Hosen\\Shorts.png", new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS}, true, false,false),
    ROCK(Geschlecht.WEIBLICH, "src\\grafik\\Kleidung\\Hosen\\Rock.png", new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS}, true, false,false),
    LEDERHOSE(Geschlecht.MAENNLICH, "src\\grafik\\Kleidung\\Hosen\\Lederhose.png", new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS}, false, false,false);
    
    private Geschlecht i;
    private String path;
    private Wetter[] main;
    private boolean istUeber20;
    private boolean istInSchrank;
    private boolean istWinter;

    private Hose(Geschlecht i, String path, Wetter[] main, boolean istUeber20, boolean istInSchrank, boolean istWinter) {
        this.i = i;
        this.path = path;
        this.main = main;
        this.istUeber20 = istUeber20;
        this.istInSchrank = istInSchrank;
        this.istWinter = istWinter;
    }

    public boolean isIstWinter() {
        return istWinter;
    }

    public void setIstWinter(boolean istWinter) {
        this.istWinter = istWinter;
    }
    
    

    public boolean isIstUeber20() {
        return istUeber20;
    }

    public void setIstUeber20(boolean istUeber20) {
        this.istUeber20 = istUeber20;
    }
    
    public Wetter[] getMain() {
        return main;
    }

    public void setMain(Wetter[] main) {
        this.main = main;
    }
    public boolean isIstInSchrank() {
        return istInSchrank;
    }

    public void setIstInSchrank(boolean istInSchrank) {
        this.istInSchrank = istInSchrank;
    }

    public Geschlecht getI() {
        return i;
    }

    public String getPath() {
        return path;
    }
    
}

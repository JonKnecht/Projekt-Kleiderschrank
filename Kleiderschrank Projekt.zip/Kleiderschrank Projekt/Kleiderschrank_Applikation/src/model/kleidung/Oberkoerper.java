/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

import model.Geschlecht;
import model.Wetter;

/**
 *
 * @author Benni
 */
public enum Oberkoerper {
    PULLOVER(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Oben\\Pullover.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},false, false,true),
    TSHIRT(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Oben\\Tshirt.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},true, false,false),
    TANKTOP(Geschlecht.MAENNLICH, "src\\grafik\\Kleidung\\Oben\\Tanktop.png",new Wetter[]{Wetter.CLEAR},true, false,false),
    BLUSE(Geschlecht.WEIBLICH, "src\\grafik\\Kleidung\\Oben\\Bluse.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},true, false,false),
    WINTERJACKE(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Oben\\Winterjacke.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS, Wetter.SNOW},false, false,true),
    REGENJACKE(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Oben\\Regenjacke.png",new Wetter[]{Wetter.RAIN, Wetter.DRIZZLE},true, false,false),
    WINDJACKE(Geschlecht.DIVERS, "src\\grafik\\Kleidung\\Oben\\Windjacke.png",new Wetter[]{Wetter.THUNDERSTORM},true, false,false);
    
    
    private Geschlecht i;
    private String path;
    private Wetter[] w;
    private boolean istueber20;
    private boolean isInSchrank;
    private boolean istWinter;

    private Oberkoerper(Geschlecht i, String path, Wetter[] w, boolean istueber20, boolean isInSchrank, boolean istWinter) {
        this.i = i;
        this.path = path;
        this.w = w;
        this.istueber20 = istueber20;
        this.isInSchrank = isInSchrank;
        this.istWinter = istWinter;
    }

    public boolean isIstWinter() {
        return istWinter;
    }

    public void setIstWinter(boolean istWinter) {
        this.istWinter = istWinter;
    }

    

    public Wetter[] getMain() {
        return w;
    }

    public void setMain(Wetter[] w) {
        this.w = w;
    }

    public boolean isIstueber20() {
        return istueber20;
    }

    public void setIstueber20(boolean istueber20) {
        this.istueber20 = istueber20;
    }

    public boolean isIsInSchrank() {
        return isInSchrank;
    }

    public void setIsInSchrank(boolean isInSchrank) {
        this.isInSchrank = isInSchrank;
    }

   

    public Geschlecht getI() {
        return i;
    }

    public String getPath() {
        return path;
    }
    
    

    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jerem
 */
@Entity
@Table(name = "SCHRANK")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Schrank.findAll", query = "SELECT s FROM Schrank s")
    , @NamedQuery(name = "Schrank.findById", query = "SELECT s FROM Schrank s WHERE s.id = :id")})
public class Schrank implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ID")
    private Integer id;
    @Lob
    @Column(name = "HOSE")
    private Serializable hose;
    @Lob
    @Column(name = "KOPF")
    private Serializable kopf;
    @Lob
    @Column(name = "OBERKOERPER")
    private Serializable oberkoerper;
    @JoinColumn(name = "P_ID", referencedColumnName = "ID")
    @ManyToOne
    private Person pId;
    @OneToMany(mappedBy = "schrankId")
    private Collection<Person> personCollection;

    public Schrank() {
    }

    public Schrank(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Serializable getHose() {
        return hose;
    }

    public void setHose(Serializable hose) {
        this.hose = hose;
    }

    public Serializable getKopf() {
        return kopf;
    }

    public void setKopf(Serializable kopf) {
        this.kopf = kopf;
    }

    public Serializable getOberkoerper() {
        return oberkoerper;
    }

    public void setOberkoerper(Serializable oberkoerper) {
        this.oberkoerper = oberkoerper;
    }

    public Person getPId() {
        return pId;
    }

    public void setPId(Person pId) {
        this.pId = pId;
    }

    @XmlTransient
    public Collection<Person> getPersonCollection() {
        return personCollection;
    }

    public void setPersonCollection(Collection<Person> personCollection) {
        this.personCollection = personCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Schrank)) {
            return false;
        }
        Schrank other = (Schrank) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Schrank[ id=" + id + " ]";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author jerem
 */
@Entity
@Table(name = "PERSON")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Person.findAll", query = "SELECT p FROM Person p")
    , @NamedQuery(name = "Person.findById", query = "SELECT p FROM Person p WHERE p.id = :id")
    , @NamedQuery(name = "Person.findByGeschl", query = "SELECT p FROM Person p WHERE p.geschl = :geschl")
    , @NamedQuery(name = "Person.findByNachname", query = "SELECT p FROM Person p WHERE p.nachname = :nachname")
    , @NamedQuery(name = "Person.findByPasswort", query = "SELECT p FROM Person p WHERE p.passwort = :passwort")
    , @NamedQuery(name = "Person.findByVorname", query = "SELECT p FROM Person p WHERE p.vorname = :vorname")})
public class Person implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "ID")
    private String id;
    @Column(name = "GESCHL")
    private Integer geschl;
    @Size(max = 255)
    @Column(name = "NACHNAME")
    private String nachname;
    @Size(max = 255)
    @Column(name = "PASSWORT")
    private String passwort;
    @Size(max = 255)
    @Column(name = "VORNAME")
    private String vorname;
    @OneToMany(mappedBy = "pId")
    private Collection<Schrank> schrankCollection;
    @JoinColumn(name = "SCHRANK_ID", referencedColumnName = "ID")
    @ManyToOne
    private Schrank schrankId;

    public Person() {
    }

    public Person(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getGeschl() {
        return geschl;
    }

    public void setGeschl(Integer geschl) {
        this.geschl = geschl;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public String getPasswort() {
        return passwort;
    }

    public void setPasswort(String passwort) {
        this.passwort = passwort;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    @XmlTransient
    public Collection<Schrank> getSchrankCollection() {
        return schrankCollection;
    }

    public void setSchrankCollection(Collection<Schrank> schrankCollection) {
        this.schrankCollection = schrankCollection;
    }

    public Schrank getSchrankId() {
        return schrankId;
    }

    public void setSchrankId(Schrank schrankId) {
        this.schrankId = schrankId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Person)) {
            return false;
        }
        Person other = (Person) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Person[ id=" + id + " ]";
    }
    
}

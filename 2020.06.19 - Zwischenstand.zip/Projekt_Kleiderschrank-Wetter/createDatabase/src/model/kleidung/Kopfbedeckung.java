/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

/**
 *
 * @author Benni
 */
public enum Kopfbedeckung {
    CAP("Kleidung\\Kopf\\Cap.png"),HAUBE("Kleidung\\Kopf\\Haube.png"),HUT("Kleidung\\Kopf\\Hut.png");
    
    private String path;

    private Kopfbedeckung(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }
    
    
}

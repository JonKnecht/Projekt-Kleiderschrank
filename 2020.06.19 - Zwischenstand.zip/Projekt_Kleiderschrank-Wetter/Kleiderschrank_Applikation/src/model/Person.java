/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Benni
 */
@XmlRootElement
public class Person implements Serializable {

    private static final long serialVersionUID = 1L;
    private String id;
    private Geschlecht geschl;
    private String nachname;
    private String passwort;
    private String vorname;
    private Schrank schrank;

    public Person(String id) {
        this.id = id;
    }

    public Person(String id, String nachname, String passwort, String vorname, Geschlecht geschl) {
        this(id);
        this.geschl = geschl;
        this.nachname = nachname;
        this.passwort = passwort;
        this.vorname = vorname;
    }

    public Person() {
    }
    
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Geschlecht getGeschl() {
        return geschl;
    }

    public void setGeschl(Geschlecht geschl) {
        this.geschl = geschl;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public String getPasswort() {
        return passwort;
    }

    public void setPasswort(String passwort) {
        this.passwort = passwort;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public Schrank getSchrankId() {
        return schrank;
    }

    public void setSchrankId(Schrank schrankId) {
        this.schrank = schrankId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Person)) {
            return false;
        }
        Person other = (Person) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Person[ id=" + id + " ]";
    }
    
}

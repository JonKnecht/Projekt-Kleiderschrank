/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author jerem
 */
public class OutfitWindow extends Stage{
    private KleiderschrankWindow kldwdw;
    private OutfitFXMLController ofc;
    
    public OutfitWindow() throws IOException {
        super();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("OutfitFXML.fxml"));
        Parent root = loader.load();
        ofc = loader.getController();
        Scene scene = new Scene(root);
        this.setScene(scene);
    }

    public KleiderschrankWindow getKldwdw() {
        return kldwdw;
    }

    public void setKldwdw(KleiderschrankWindow kldwdw) {
        this.kldwdw = kldwdw;
    }

    public OutfitFXMLController getOfc() {
        return ofc;
    }
    
    
}

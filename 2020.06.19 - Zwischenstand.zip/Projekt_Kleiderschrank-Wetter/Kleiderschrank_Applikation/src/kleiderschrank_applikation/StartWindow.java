/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author jerem
 */
public class StartWindow extends Stage{
    private OutfitWindow outwdw;
    private KleiderschrankWindow kldwdw;
    private StartFXMLController sfc;
    
    public StartWindow() throws IOException {
        super();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("StartFXML.fxml"));
        Parent root = loader.load();
        sfc = loader.getController();
        Scene scene = new Scene(root);
        this.setScene(scene);
        this.show();
    }

    public OutfitWindow getOutwdw() {
        return outwdw;
    }

    public void setOutwdw(OutfitWindow outwdw) {
        this.outwdw = outwdw;
    }

    public KleiderschrankWindow getKldwdw() {
        return kldwdw;
    }

    public void setKldwdw(KleiderschrankWindow kldwdw) {
        this.kldwdw = kldwdw;
    }

    public StartFXMLController getSfc() {
        return sfc;
    }
    
    
    
}

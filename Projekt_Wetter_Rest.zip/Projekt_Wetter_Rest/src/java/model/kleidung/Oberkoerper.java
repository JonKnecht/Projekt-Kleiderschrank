/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

import model.Geschlecht;

/**
 *
 * @author Benni
 */
public enum Oberkoerper {
    PULLOVER(Geschlecht.DIVERS, "Kleidung\\Oben\\Pullover.png"),
    TSHIRT(Geschlecht.DIVERS, "Kleidung\\Oben\\Tshirt.png"),
    TANKTOP(Geschlecht.MAENNLICH, "Kleidung\\Oben\\Tanktop.png"),
    BLUSE(Geschlecht.WEIBLICH, "Kleidung\\Oben\\Bluse.png"),
    WINTERJACKE(Geschlecht.DIVERS, "Kleidung\\Oben\\Winterjacke.png"),
    REGENJACKE(Geschlecht.DIVERS, "Kleidung\\Oben\\Regenjacke.png"),
    WINDJACKE(Geschlecht.DIVERS, "Kleidung\\Oben\\Windjacke.png");
    
    private String path;
    private Geschlecht i;

    private Oberkoerper(Geschlecht i, String path) {
        this.i = i;
        this.path = path;
    }

    public Geschlecht getI() {
        return i;
    }

    public String getPath() {
        return path;
    }
    
    

    
    
    
}

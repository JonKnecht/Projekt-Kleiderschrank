
import com.sun.jersey.api.client.WebResource;
import java.util.List;
import javax.ws.rs.core.MediaType;
import model.Person;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jerem
 */
public class test {
    public static void main(String[] args){
    WebResource s1 = com.sun.jersey.api.client.Client.create()
                .resource("http://localhost:8080/Kleiderschrank-REST/webresources/model.person");
    
//        WebResource s1 = com.sun.jersey.api.client.Client.create()
//                .resource("http://localhost:8080/Kleiderschrank-REST/webresources/model.person");
//        s1.type(MediaType.APPLICATION_XML);
//        Person p = null;
//        s1.post(Person.class, p);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.LinkedList;
import javax.xml.bind.annotation.XmlRootElement;
import model.kleidung.Hose;
import model.kleidung.Kopfbedeckung;
import model.kleidung.Oberkoerper;

/**
 *
 * @author jerem
 */

public class Schrank implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    LinkedList<Hose> hose;
    LinkedList<Kopfbedeckung> kopf;
    LinkedList<Oberkoerper> oberkoerper;

    public Schrank(int id) {
        this.id = id;
    }

    public Schrank(int id, LinkedList<Hose> hose, LinkedList<Kopfbedeckung> kopf, LinkedList<Oberkoerper> oberkoerper) {
        this(id);
        this.hose = hose;
        this.kopf = kopf;
        this.oberkoerper = oberkoerper;
    }

    public LinkedList<Hose> getHose() {
        return hose;
    }

    public Schrank() {
        this.id = 0;
    }
    
    

    public void setHose(LinkedList<Hose> hose) {
        this.hose = hose;
    }

    public LinkedList<Kopfbedeckung> getKopf() {
        return kopf;
    }

    public void setKopf(LinkedList<Kopfbedeckung> kopf) {
        this.kopf = kopf;
    }

    public LinkedList<Oberkoerper> getOberkoerper() {
        return oberkoerper;
    }

    public void setOberkoerper(LinkedList<Oberkoerper> oberkoerper) {
        this.oberkoerper = oberkoerper;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) id;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Schrank)) {
            return false;
        }
        Schrank other = (Schrank) object;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Schrank[ id=" + id + " ]";
    }
    
}

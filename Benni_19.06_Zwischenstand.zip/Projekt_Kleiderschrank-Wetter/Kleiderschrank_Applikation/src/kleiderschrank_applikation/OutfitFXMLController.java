/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import sun.net.www.protocol.https.HttpsURLConnectionImpl;

/**
 * FXML Controller class
 *
 * @author jerem
 */
public class OutfitFXMLController implements Initializable {

    @FXML
    private ImageView kopfImage;
    @FXML
    private ImageView obenImage;
    @FXML
    private ImageView untenImage;
    @FXML
    private Button changeButton;
    @FXML
    private AnchorPane anchor;
    @FXML
    private TextField ortField;
    @FXML
    private Button editButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void handleChangeButton(ActionEvent event) throws IOException {
        JsonObject jo = getJsonWetterdaten(ortField.getText());
        System.out.println(""+jo.toString());

    }

    @FXML
    private void handleEditButton(ActionEvent event) {
        OutfitWindow stage = (OutfitWindow) anchor.getScene().getWindow();
        stage.hide();
        KleiderschrankWindow kw = stage.getKldwdw();
        kw.show();
    }

    private static JsonObject getJsonWetterdaten(String ort) throws MalformedURLException, IOException {
        final String APIkey = "f60681cfe21d54e6f9268ea380d1e3a8";
        String urlString = "https://api.openweathermap.org/data/2.5/weather?q=" + ort + "&appid=" + APIkey;
        URL url = new URL(urlString);
        HttpsURLConnectionImpl conn = (HttpsURLConnectionImpl) url.openConnection();
        conn.connect();
        JsonParser jp = new JsonParser();
        JsonElement root = jp.parse(new InputStreamReader((InputStream) conn.getContent()));
        JsonObject obj = root.getAsJsonObject();
        return obj;
    }

}

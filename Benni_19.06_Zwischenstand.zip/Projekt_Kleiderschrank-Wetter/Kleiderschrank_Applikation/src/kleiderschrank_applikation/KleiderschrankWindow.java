/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author jerem
 */
public class KleiderschrankWindow extends Stage{
    OutfitWindow outwdw;
    KleiderschrankFXMLController kfc;
    
    public KleiderschrankWindow() throws IOException {
        super();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("KleiderschrankFXML.fxml"));
        Parent root = loader.load();
        kfc = loader.getController();
        Scene scene = new Scene(root);
        this.setScene(scene);
    }

    public OutfitWindow getOutwdw() {
        return outwdw;
    }

    public void setOutwdw(OutfitWindow outwdw) {
        this.outwdw = outwdw;
    }

    public KleiderschrankFXMLController getKfc() {
        return kfc;
    }
    
    
}

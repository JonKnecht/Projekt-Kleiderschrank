/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import com.sun.jersey.api.client.WebResource;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.ws.rs.core.MediaType;
import model.Geschlecht;
import model.Person;
import model.Schrank;
import model.kleidung.Hose;
import model.kleidung.Kopfbedeckung;
import model.kleidung.Oberkoerper;

/**
 * FXML Controller class
 *
 * @author jerem
 */
public class StartFXMLController implements Initializable {

    @FXML
    private TextField loginUserName;
    @FXML
    private PasswordField loginPassword;
    @FXML
    private TextField signupFirstName;
    @FXML
    private TextField signupLastName;
    @FXML
    private TextField signupUserName;
    @FXML
    private PasswordField signupPassword;
    @FXML
    private Spinner<String> signupGender;
    @FXML
    private Button loginButton;
    @FXML
    private Button signupButton;
    @FXML
    private Label signupFehlerLabel;
    @FXML
    private Label loginFehlerLabel;
    @FXML
    private AnchorPane anchor;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<String> months = FXCollections.observableArrayList(//
                "MAENNLICH", "WEIBLICH", "DIVERS");
        SpinnerValueFactory<String> valueFactory
                = //
                new SpinnerValueFactory.ListSpinnerValueFactory<String>(months);
        signupGender.setValueFactory(valueFactory);

        initializeLeerzeichenRegeln();
    }

    @FXML
    private void handleLoginButton(ActionEvent event) {
        StartWindow stage = (StartWindow) anchor.getScene().getWindow();
        stage.hide();
        OutfitWindow ow = stage.getOutwdw();
        ow.show();
    }

    @FXML
    private void handleSignUpButton(ActionEvent event) throws FileNotFoundException {
        String vorname = signupFirstName.getText();
        String nachname = signupLastName.getText();
        String nutzer = signupUserName.getText();
        String pass = signupPassword.getText();
        String geschl = signupGender.getValue();
        Geschlecht geschle = Geschlecht.valueOf(geschl);
        Person p = new Person(nutzer, nachname, pass, vorname, geschle);
        Schrank s = new Schrank(0, new LinkedList<Hose>(), new LinkedList<Kopfbedeckung>(), new LinkedList<>());

        //in Datenbank einfuegen
//        WebResource s1 = com.sun.jersey.api.client.Client.create()
//                .resource("http://localhost:8080/Kleiderschrank-REST/webresources/model.person");
//        s1.type(MediaType.APPLICATION_XML);
//        s1.post(Person.class, p);

        //Vorbereitung Wechsel in den Kleiderschrank
        StartWindow stage = (StartWindow) anchor.getScene().getWindow();
        KleiderschrankWindow kw = stage.getKldwdw();

        LinkedList<Hose> llHose = new LinkedList<>();
        LinkedList<Kopfbedeckung> llKopf = new LinkedList<>();
        LinkedList<Oberkoerper> llOben = new LinkedList<>();

        if (geschle == Geschlecht.DIVERS) {
            llHose.addAll(Arrays.asList(Hose.values()));
        } else {
            for (Hose h : Hose.values()) {
                if (h.getI() == p.getGeschl() || h.getI() == Geschlecht.DIVERS) {
                    llHose.add(h);
                }
            }
        }

        
        if (geschle == Geschlecht.DIVERS) {
            llOben.addAll(Arrays.asList(Oberkoerper.values()));
        }else{
            for (Oberkoerper h : Oberkoerper.values()) {
            if (h.getI() == p.getGeschl() || h.getI() == Geschlecht.DIVERS) {
                llOben.add(h);
            }
        }
        }

        llKopf.addAll(Arrays.asList(Kopfbedeckung.values()));

        KleiderschrankFXMLController kfc = kw.getKfc();
        kfc.setLlHose(llHose);
        kfc.setLlKopf(llKopf);
        kfc.setLlOben(llOben);
        
        kfc.getAuswKopf().setImage(new Image(new FileInputStream(llKopf.get(0).getPath())));
        kfc.getAuswUnten().setImage(new Image(new FileInputStream(llHose.get(0).getPath())));
        kfc.getAuswOben().setImage(new Image(new FileInputStream(llOben.get(0).getPath())));

        stage.hide();

        kw.show();
    }

    private void initializeLeerzeichenRegeln() {
        signupUserName.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getText().equals(" ")) {
                change.setText("");
            }
            return change;
        }));
        loginUserName.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getText().equals(" ")) {
                change.setText("");
            }
            return change;
        }));

        signupPassword.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getText().equals(" ")) {
                change.setText("");
            }
            return change;
        }));
        signupPassword.setTextFormatter(new TextFormatter<>(change -> {
            if (change.getText().equals(" ")) {
                change.setText("");
            }
            return change;
        }));
    }
}

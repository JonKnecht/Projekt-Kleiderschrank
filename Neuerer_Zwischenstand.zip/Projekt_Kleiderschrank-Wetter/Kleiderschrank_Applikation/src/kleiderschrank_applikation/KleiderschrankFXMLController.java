/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import com.sun.jersey.api.client.WebResource;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javax.ws.rs.core.MediaType;
import model.Geschlecht;
import model.Person;
import model.Schrank;
import model.kleidung.Hose;
import model.kleidung.Kopfbedeckung;
import model.kleidung.Oberkoerper;

/**
 * FXML Controller class
 *
 * @author jerem
 */
public class KleiderschrankFXMLController implements Initializable {

    @FXML
    private ImageView auswKopf;
    @FXML
    private ImageView auswOben;
    @FXML
    private ImageView auswUnten;
    @FXML
    private ImageView kldKopf;
    @FXML
    private ImageView kldOben;
    @FXML
    private ImageView kldUnten;
    @FXML
    private Button auswKopfRechts;
    @FXML
    private Button auswKopfLinks;
    @FXML
    private Button auswObenRechts;
    @FXML
    private Button auswUntenRechts;
    @FXML
    private Button auswUntenLinks;
    @FXML
    private Button kldKopfRechts;
    @FXML
    private Button kldKopfLinks;
    @FXML
    private Button kldObenRechts;
    @FXML
    private Button kldUntenRechts;
    @FXML
    private Button kldObenLinks;
    @FXML
    private Button kldUntenLinks;
    @FXML
    private Button fertigButton;
    @FXML
    private AnchorPane anchor;
    private Schrank auswahl;
    private LinkedList<Kopfbedeckung> llKopf;
    private int llKopfLauf = 0;
    private LinkedList<Hose> llHose;
    private int llHoseLauf = 0;
    private LinkedList<Oberkoerper> llOben;
    private int llObenLauf = 0;
    @FXML
    private Button auswObenLinkks;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

//       llKopf = new LinkedList<Kopfbedeckung>(Arrays.asList(Kopfbedeckung.values()));
//       llHose = new LinkedList<Hose>(Arrays.asList(Hose.values()));
//       llOben = new LinkedList<Oberkoerper>(Arrays.asList(Oberkoerper.values()));
//       
//        try {
//            auswKopf.setImage(new Image(new FileInputStream(llKopf.get(llKopfLauf).getPath())));
//            auswUnten.setImage(new Image(new FileInputStream(llHose.get(llHoseLauf).getPath())));
//            auswOben.setImage(new Image(new FileInputStream(llOben.get(llObenLauf).getPath())));
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(KleiderschrankFXMLController.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }    

    @FXML
    private void handleAuswKopf(MouseEvent event) {
    }


    @FXML
    private void handleAuswUnten(MouseEvent event) {
    }

    @FXML
    private void handleKldKopf(MouseEvent event) {
    }

    @FXML
    private void handleKldOben(MouseEvent event) {
    }

    @FXML
    private void handleKldUnten(MouseEvent event) {
    }

    @FXML
    private void handleAuswKopfRechts(ActionEvent event) throws FileNotFoundException {
        if(llKopfLauf == llKopf.size()-1){
            llKopfLauf = 0;
            auswKopf.setImage(new Image(new FileInputStream(llKopf.get(llKopfLauf).getPath())));
        }else{
            llKopfLauf++;
            auswKopf.setImage(new Image(new FileInputStream(llKopf.get(llKopfLauf).getPath())));
        }
        
    }

    @FXML
    private void handleAuswKopfLinks(ActionEvent event) throws FileNotFoundException {
        if(llKopfLauf == 0){
            llKopfLauf = llKopf.size()-1;
            auswKopf.setImage(new Image(new FileInputStream(llKopf.get(llKopfLauf).getPath())));
        }else{
            llKopfLauf--;
            auswKopf.setImage(new Image(new FileInputStream(llKopf.get(llKopfLauf).getPath())));
        }
    }

    @FXML
    private void handleAuswObenLinks(ActionEvent event) throws FileNotFoundException {
        if(llObenLauf == 0){
            llObenLauf = llOben.size()-1;
            auswOben.setImage(new Image(new FileInputStream(llOben.get(llObenLauf).getPath())));
        }else{
            llObenLauf--;
            auswOben.setImage(new Image(new FileInputStream(llOben.get(llObenLauf).getPath())));
        }
    }

    @FXML
    private void handleAuswObenRechts(ActionEvent event) throws FileNotFoundException {
        if(llObenLauf == llOben.size()-1){
            llObenLauf = 0;
            auswOben.setImage(new Image(new FileInputStream(llOben.get(llObenLauf).getPath())));
        }else{
            llObenLauf++;
            auswOben.setImage(new Image(new FileInputStream(llOben.get(llObenLauf).getPath())));
        }
    }

    @FXML
    private void handleAuswUntenRechts(ActionEvent event) throws FileNotFoundException {
        if(llHoseLauf == llHose.size()-1){
            llHoseLauf = 0;
            auswUnten.setImage(new Image(new FileInputStream(llHose.get(llHoseLauf).getPath())));
        }else{
            llHoseLauf++;
            auswUnten.setImage(new Image(new FileInputStream(llHose.get(llHoseLauf).getPath())));
        }
    }

    @FXML
    private void handleAuswUntenLinks(ActionEvent event) throws FileNotFoundException {
        if(llHoseLauf == 0){
            llHoseLauf = llHose.size()-1;
            auswUnten.setImage(new Image(new FileInputStream(llHose.get(llHoseLauf).getPath())));
        }else{
            llHoseLauf--;
            auswUnten.setImage(new Image(new FileInputStream(llHose.get(llHoseLauf).getPath())));
        }
    }

    @FXML
    private void handleKldKopfRechts(ActionEvent event) {
         
    }

    @FXML
    private void handleKldKopfLinks(ActionEvent event) {
    }

    @FXML
    private void handleKldObenRechts(ActionEvent event) {
    }

    @FXML
    private void handleKldUntenRechts(ActionEvent event) {
    }

    @FXML
    private void handleKldObenLinks(ActionEvent event) {
    }

    @FXML
    private void handleKldUntenLinks(ActionEvent event) {
    }

    @FXML
    private void handleFertigButton(ActionEvent event) {
        KleiderschrankWindow stage = (KleiderschrankWindow) anchor.getScene().getWindow();
        stage.hide();
        OutfitWindow ow = stage.getOutwdw();
        ow.show();
    }

    public ImageView getAuswKopf() {
        return auswKopf;
    }

    public void setAuswKopf(ImageView auswKopf) {
        this.auswKopf = auswKopf;
    }

    public ImageView getAuswOben() {
        return auswOben;
    }

    public void setAuswOben(ImageView auswOben) {
        this.auswOben = auswOben;
    }

    public ImageView getAuswUnten() {
        return auswUnten;
    }

    public void setAuswUnten(ImageView auswUnten) {
        this.auswUnten = auswUnten;
    }

    public ImageView getKldKopf() {
        return kldKopf;
    }

    public void setKldKopf(ImageView kldKopf) {
        this.kldKopf = kldKopf;
    }

    public ImageView getKldOben() {
        return kldOben;
    }

    public void setKldOben(ImageView kldOben) {
        this.kldOben = kldOben;
    }

    public ImageView getKldUnten() {
        return kldUnten;
    }

    public void setKldUnten(ImageView kldUnten) {
        this.kldUnten = kldUnten;
    }

    public LinkedList<Kopfbedeckung> getLlKopf() {
        return llKopf;
    }

    public void setLlKopf(LinkedList<Kopfbedeckung> llKopf) {
        this.llKopf = llKopf;
    }

    public LinkedList<Hose> getLlHose() {
        return llHose;
    }

    public void setLlHose(LinkedList<Hose> llHose) {
        this.llHose = llHose;
    }

    public LinkedList<Oberkoerper> getLlOben() {
        return llOben;
    }

    public void setLlOben(LinkedList<Oberkoerper> llOben) {
        this.llOben = llOben;
    }
    
    
    
}

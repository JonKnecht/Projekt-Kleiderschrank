/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kleiderschrank_applikation;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author jerem
 */
public class OutfitFXMLController implements Initializable {

    @FXML
    private ImageView kopfImage;
    @FXML
    private ImageView obenImage;
    @FXML
    private ImageView untenImage;
    @FXML
    private Button changeButton;
    @FXML
    private AnchorPane anchor;
    @FXML
    private TextField ortField;
    @FXML
    private Button editButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleChangeButton(ActionEvent event) {
        
    }

    @FXML
    private void handleEditButton(ActionEvent event) {
        OutfitWindow stage = (OutfitWindow) anchor.getScene().getWindow();
        stage.hide();
        KleiderschrankWindow kw = stage.getKldwdw();
        kw.show();
    }
    
}

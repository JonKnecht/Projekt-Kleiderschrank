/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 *
 * @author jerem
 */
@Entity
public class Person implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    private String id;
    private String passwort;
    private String vorname;
    private String nachname;
    private Geschlecht geschl;
    
    @OneToOne
    private Schrank schrank;

    public Person(String passwort, String vorname, String nachname, String id, Geschlecht geschl) {
        this.passwort = passwort;
        this.vorname = vorname;
        this.nachname = nachname;
        this.id = id;
        this.geschl = geschl;
    }

    public Person() {
    }

    public Geschlecht getGeschl() {
        return geschl;
    }

    public void setGeschl(Geschlecht geschl) {
        this.geschl = geschl;
    }


    
    

    public String getPasswort() {
        return passwort;
    }

    public void setPasswort(String passwort) {
        this.passwort = passwort;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    public Schrank getSchrank() {
        return schrank;
    }

    public void setSchrank(Schrank schrank) {
        this.schrank = schrank;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Person)) {
            return false;
        }
        Person other = (Person) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Person[ id=" + id + " ]";
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.LinkedList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;
import model.kleidung.Hose;
import model.kleidung.Kopfbedeckung;
import model.kleidung.Oberkoerper;

/**
 *
 * @author jerem
 */
@Entity
@XmlRootElement
public class Schrank implements Serializable {

 

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    @OneToOne
    private Person p;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    LinkedList<Hose> hose;
    LinkedList<Kopfbedeckung> kopf;
    LinkedList<Oberkoerper> oberkoerper;

    public Schrank(LinkedList<Hose> hose, LinkedList<Kopfbedeckung> kopf, LinkedList<Oberkoerper> oberkoerper) {
        this.hose = hose;
        this.kopf = kopf;
        this.oberkoerper = oberkoerper;
    }

    public Schrank() {
        hose = new LinkedList<>();
        kopf = new LinkedList<>();
        oberkoerper = new LinkedList<>();
    }

    
    
    public LinkedList<Hose> getHose() {
        return hose;
    }

    public void setHose(LinkedList<Hose> hose) {
        this.hose = hose;
    }

    public LinkedList<Kopfbedeckung> getKopf() {
        return kopf;
    }

    public void setKopf(LinkedList<Kopfbedeckung> kopf) {
        this.kopf = kopf;
    }

    public LinkedList<Oberkoerper> getOberkörper() {
        return oberkoerper;
    }

    public void setOberkörper(LinkedList<Oberkoerper> oberkörper) {
        this.oberkoerper = oberkörper;
    }

    public Schrank(Integer id) {
        this.id = id;
    }



    

    @Override
    public String toString() {
        return "model.Schrank[ id=" + id + " ]";
    }
    
    
}

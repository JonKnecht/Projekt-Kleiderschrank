/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt_wetter;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Geschlecht;
import model.Person;
import model_controller.PersonJpaController;
import model_controller.SchrankJpaController;

/**
 *
 * @author Benni
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TextField VornameField;
    @FXML
    private TextField NachnameField;
    @FXML
    private TextField registerNutzerField;
    @FXML
    private PasswordField registerPasswordField;
    @FXML
    private TextField anmeldenNutzerField;
    @FXML
    private PasswordField anmeldenPasswordField;
    @FXML
    private Button anmeldenButton;
    @FXML
    private Button onRegistrierenButton;
    @FXML
    private Label PasswortLabel;
    @FXML
    private AnchorPane anchor;
    @FXML
    private Spinner<String> geschlechtSpinner;
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    PersonJpaController pjc;
    SchrankJpaController scj;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         ObservableList<String> months = FXCollections.observableArrayList(//
              "MAENNLICH", "WEIBLICH", "DIVERS");
          SpinnerValueFactory<String> valueFactory = //
               new SpinnerValueFactory.ListSpinnerValueFactory<String>(months);
          geschlechtSpinner.setValueFactory(valueFactory);
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("Projekt_WetterPU");
        pjc = new PersonJpaController(emf);
        scj = new SchrankJpaController(emf);
        registerNutzerField.setTextFormatter(new TextFormatter<>(change -> {
    if (change.getText().equals(" ")) {
        change.setText("");
    }
    return change;
}));
        anmeldenNutzerField.setTextFormatter(new TextFormatter<>(change -> {
    if (change.getText().equals(" ")) {
        change.setText("");
    }
    return change;
}));
        
        registerPasswordField.setTextFormatter(new TextFormatter<>(change -> {
    if (change.getText().equals(" ")) {
        change.setText("");
    }
    return change;
}));
        anmeldenPasswordField.setTextFormatter(new TextFormatter<>(change -> {
    if (change.getText().equals(" ")) {
        change.setText("");
    }
    return change;
}));
    }    

    @FXML
    private void onAnmeldenButton(ActionEvent event) {
        String user = anmeldenNutzerField.getText();
        
        
        Person p = pjc.findPerson(user);
        
        if(anmeldenPasswordField.getText().equals(p.getPasswort())==true){
            PasswortLabel.setText("Passwort stimmt");
         System.out.println(p.getNachname());   
        }
        else{
            PasswortLabel.setText("Passwort stimmt nicht überein");
        }
    }

    @FXML
    private void onRegisterButton(ActionEvent event) throws Exception {
        String vorname = VornameField.getText();
        String nachname = NachnameField.getText();
        String nutzer = registerNutzerField.getText();
        String pass = registerPasswordField.getText();
        String geschl = geschlechtSpinner.getValue();
        Geschlecht geschle = Geschlecht.valueOf(geschl);
        Person p = new Person(pass, vorname, nachname, nutzer, geschle);
        pjc.create(p);
        
        Stage s = (Stage) anchor.getScene().getWindow();
        
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MainFenster.fxml"));
        Parent root = loader.load();
                MainFensterController dc = (MainFensterController) loader.getController();
        Scene scene1 = new Scene(root);
        s.setScene(scene1);
        
        s.show();
        
    }

    public TextField getRegisterNutzerField() {
        return registerNutzerField;
    }

    public void setRegisterNutzerField(TextField registerNutzerField) {
        this.registerNutzerField = registerNutzerField;
    }
    
}

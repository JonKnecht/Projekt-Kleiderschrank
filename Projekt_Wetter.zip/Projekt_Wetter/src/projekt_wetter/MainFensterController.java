/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt_wetter;

import Kleidung.Hosen;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.ListView;

/**
 * FXML Controller class
 *
 * @author Benni
 */
public class MainFensterController implements Initializable {

    @FXML
    private ListView<String> hinzuListView;

    /**
     * Initializes the controller class.
     */
    public Hosen hosen;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    

    @FXML
    private void onHinzufügenButton(ActionEvent event) {
         try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml")); 
            Parent root = loader.load();
            FXMLDocumentController dc = (FXMLDocumentController) loader.getController();
            String nutzer = dc.getRegisterNutzerField().getText();
            System.out.println(nutzer);
                    // TODO
                    } catch (IOException ex) {
            Logger.getLogger(MainFensterController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}

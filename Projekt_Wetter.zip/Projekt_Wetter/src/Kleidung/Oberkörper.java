/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kleidung;

import model.Geschlecht;

/**
 *
 * @author Benni
 */
public enum Oberkörper {
    PULLOVER(Geschlecht.DIVERS),TSHIRT(Geschlecht.DIVERS),TANKTOP(Geschlecht.MAENNLICH),BLUSE(Geschlecht.WEIBLICH),WINTERJACKE(Geschlecht.DIVERS),REGENJACKE(Geschlecht.DIVERS),WINDJACKE(Geschlecht.DIVERS);
    private Geschlecht i;

    private Oberkörper(Geschlecht i) {
        this.i = i;
    }

    public Geschlecht getI() {
        return i;
    }

    
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kleidung;

import model.Geschlecht;

/**
 *
 * @author Benni
 */
public enum Hosen {
    JEANS(Geschlecht.DIVERS),SHORTJEANS(Geschlecht.WEIBLICH),LEGGINGS(Geschlecht.WEIBLICH),JOGGINGHOSE(Geschlecht.DIVERS),SHORTS(Geschlecht.MAENNLICH),ROCK(Geschlecht.WEIBLICH),LEDERHOSE(Geschlecht.MAENNLICH);
     private Geschlecht i;

    private Hosen(Geschlecht i) {
        this.i = i;
    }

    public Geschlecht getI() {
        return i;
    }
}

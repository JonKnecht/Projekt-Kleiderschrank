/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Benni
 */
public enum Wetter {
    RAIN,SNOW,CLOUDS,CLEAR,DRIZZLE,THUNDERSTORM;
    
    @Override
     public String toString(){
        switch(this){
        case RAIN:
            return "Rain";
        case SNOW :
            return "Snow";
        case CLOUDS :
            return "Clouds";
        case CLEAR:
            return "Clear";
        case DRIZZLE:
            return "Drizzle";
        case THUNDERSTORM:
            return "Thunderstorm";
        }
        return null;
    }
}

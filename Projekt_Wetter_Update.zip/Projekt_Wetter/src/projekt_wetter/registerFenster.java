/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt_wetter;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Benni
 */
public class registerFenster extends Stage{
       kleiderSchrankFenster secondWindow;
    FXMLDocumentController fdc;
    public registerFenster() throws IOException{
        super();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
        Parent root = loader.load();
        fdc = loader.getController();
        Scene scene = new Scene(root);
        this.setScene(scene);
        this.show();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt_wetter;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Benni
 */
public class Projekt_Wetter extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
          registerFenster fenster1 = new registerFenster();
        kleiderSchrankFenster fenster2 = new kleiderSchrankFenster();
        fenster1.secondWindow = fenster2;
        fenster2.firstWindow = fenster1;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

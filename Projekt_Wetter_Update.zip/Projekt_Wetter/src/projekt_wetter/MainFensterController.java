/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt_wetter;

import Kleidung.Hosen;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Person;
import model_controller.PersonJpaController;
import model_controller.SchrankJpaController;

/**
 * FXML Controller class
 *
 * @author Benni
 */
public class MainFensterController implements Initializable {

    @FXML
    private ListView<String> hinzuListView;

    /**
     * Initializes the controller class.
     */
    public Hosen hosen;
    @FXML
    private AnchorPane anchor;
    
    PersonJpaController pjc;
    SchrankJpaController scj;
    @FXML
    private Label nutzernameLabel;
    
    Person p;
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("Projekt_WetterPU");
            pjc = new PersonJpaController(emf);
            scj = new SchrankJpaController(emf);
            nutzernameLabel.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> ov, String t, String t1) {
               System.out.println("Label Text Changed");
               System.out.println(nutzernameLabel.getText());
               p = pjc.findPerson(nutzernameLabel.getText());
            }

              
        }); 

      
    }    

    @FXML
    private void onHinzufügenButton(ActionEvent event) {
//         try {
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLDocument.fxml")); 
//            Parent root = loader.load();
//            FXMLDocumentController dc = (FXMLDocumentController) loader.getController();
//            String nutzer = dc.getRegisterNutzerField().getText();
//            System.out.println(nutzer);
//                    // TODO
//                    } catch (IOException ex) {
//            Logger.getLogger(MainFensterController.class.getName()).log(Level.SEVERE, null, ex);

//        }
    }

    public ListView<String> getHinzuListView() {
        return hinzuListView;
    }

    public void setHinzuListView(ListView<String> hinzuListView) {
        this.hinzuListView = hinzuListView;
    }

    public Hosen getHosen() {
        return hosen;
    }

    public void setHosen(Hosen hosen) {
        this.hosen = hosen;
    }

    @FXML
    private void onZurueckAction(ActionEvent event) {
       kleiderSchrankFenster stage =  (kleiderSchrankFenster) anchor.getScene().getWindow();
        stage.hide();
        
        registerFenster fenster2 = stage.firstWindow;
        fenster2.show();
        hinzuListView.getItems().clear();
        
        
    }

    public Label getNutzernameLabel() {
        return nutzernameLabel;
    }

    public void setNutzernameLabel(Label nutzernameLabel) {
        this.nutzernameLabel = nutzernameLabel;
    }
    
    
    
}

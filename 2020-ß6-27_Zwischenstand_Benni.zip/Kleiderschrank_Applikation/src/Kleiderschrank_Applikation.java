/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import javafx.application.Application;
import javafx.stage.Stage;
import grafik.KleiderschrankWindow;
import grafik.OutfitWindow;
import grafik.StartWindow;

/**
 *
 * @author jerem
 */
public class Kleiderschrank_Applikation extends Application {
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        StartWindow sw = new StartWindow();
        KleiderschrankWindow kw = new KleiderschrankWindow();
        OutfitWindow ow = new OutfitWindow();
        
        sw.setKldwdw(kw);
        sw.setOutwdw(ow);
        kw.setOutwdw(ow);
        ow.setKldwdw(kw);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

import model.Wetter;

/**
 *
 * @author Benni
 */
public enum Kopfbedeckung {
    CAP("Kleidung\\Kopf\\Cap.png", new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},true,false),
    HAUBE("Kleidung\\Kopf\\Haube.png", new Wetter[]{Wetter.SNOW, Wetter.THUNDERSTORM, Wetter.CLOUDS},false, false),
    HUT("Kleidung\\Kopf\\Hut.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS, Wetter.RAIN},true,false);
    
    private String path;
    private Wetter[] main;
    private boolean temperature;
    private boolean istInSchrank;

    private Kopfbedeckung(String path, Wetter[] main, boolean temperature, boolean istInSchrank) {
        this.path = path;
        this.main = main;
        this.temperature = temperature;
        this.istInSchrank = istInSchrank;
    }

    public Wetter[] getMain() {
        return main;
    }

    public void setMain(Wetter[] main) {
        this.main = main;
    }

    public boolean isTemperature() {
        return temperature;
    }

    public void setTemperature(boolean temperature) {
        this.temperature = temperature;
    }

    

    public boolean isIstInSchrank() {
        return istInSchrank;
    }

    public void setIstInSchrank(boolean istInSchrank) {
        this.istInSchrank = istInSchrank;
    }
    
    

    private Kopfbedeckung(String path) {
        this.path = path;
    }

    public String getPath() {
        return path;
    }
    
    
}

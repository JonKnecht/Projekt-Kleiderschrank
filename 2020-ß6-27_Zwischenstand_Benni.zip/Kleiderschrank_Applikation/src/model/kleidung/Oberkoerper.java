/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.kleidung;

import model.Geschlecht;
import model.Wetter;

/**
 *
 * @author Benni
 */
public enum Oberkoerper {
    PULLOVER(Geschlecht.DIVERS, "Kleidung\\Oben\\Pullover.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},false, false),
    TSHIRT(Geschlecht.DIVERS, "Kleidung\\Oben\\Tshirt.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},true, false),
    TANKTOP(Geschlecht.MAENNLICH, "Kleidung\\Oben\\Tanktop.png",new Wetter[]{Wetter.CLEAR},true, false),
    BLUSE(Geschlecht.WEIBLICH, "Kleidung\\Oben\\Bluse.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS},true, false),
    WINTERJACKE(Geschlecht.DIVERS, "Kleidung\\Oben\\Winterjacke.png",new Wetter[]{Wetter.CLEAR, Wetter.CLOUDS, Wetter.SNOW},false, false),
    REGENJACKE(Geschlecht.DIVERS, "Kleidung\\Oben\\Regenjacke.png",new Wetter[]{Wetter.RAIN, Wetter.DRIZZLE},false, false),
    WINDJACKE(Geschlecht.DIVERS, "Kleidung\\Oben\\Windjacke.png",new Wetter[]{Wetter.THUNDERSTORM},true, false);
    
    
    private Geschlecht i;
    private String path;
    private Wetter[] w;
    private boolean istueber20;
    private boolean isInSchrank;

    private Oberkoerper(Geschlecht i, String path, Wetter[] w, boolean istueber20, boolean isInSchrank) {
        this.i = i;
        this.path = path;
        this.w = w;
        this.istueber20 = istueber20;
        this.isInSchrank = isInSchrank;
    }

    

    public Wetter[] getMain() {
        return w;
    }

    public void setMain(Wetter[] w) {
        this.w = w;
    }

    public boolean isIstueber20() {
        return istueber20;
    }

    public void setIstueber20(boolean istueber20) {
        this.istueber20 = istueber20;
    }

    public boolean isIsInSchrank() {
        return isInSchrank;
    }

    public void setIsInSchrank(boolean isInSchrank) {
        this.isInSchrank = isInSchrank;
    }

   

    public Geschlecht getI() {
        return i;
    }

    public String getPath() {
        return path;
    }
    
    

    
    
    
}
